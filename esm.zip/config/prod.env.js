'use strict'
const config = require('./index');
module.exports = {
  NODE_ENV: '"production"',
  // 打包发布时修改下面地址
  BASE_API: '"http://www.emsapi.norain.top/api/"',
}

