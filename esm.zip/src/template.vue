<template>
    <div></div>
</template>

<script>
    export default {
        name: "template"
    }
</script>

<style scoped>

</style>
