<template>
    <div class="com-body">
      <el-row :gutter="10">
        <el-col :span="8">
          <div class="label-wrap">
            <label>项目名称：</label>
            <span>测试</span>
          </div>
        </el-col>
        <el-col :span="8">
          <div class="label-wrap">
            <label>项目编码：</label>
            <span>测试</span>
          </div>
        </el-col>
        <el-col :span="8">
          <div class="label-wrap">
            <label>绑定设备：</label>
            <span>测试</span>
          </div>
        </el-col>
        <el-col :span="24">
          <div class="label-wrap">
            <label>项目要求：</label>
            <span>测试</span>
          </div>
        </el-col>
        <el-col :span="24">
          <div class="label-wrap">
            <label>注意事项：</label>
            <span>测试</span>
          </div>
        </el-col>
        <el-col :span="24">
          <div class="label-wrap">
            <label>检测危险点：</label>
            <span>测试</span>
          </div>
        </el-col>
      </el-row>
    </div>
</template>

<script>
    export default {
        name: "detail"
    }
</script>

<style scoped>

</style>
