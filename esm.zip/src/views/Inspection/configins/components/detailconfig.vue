<template>
    <div class="com-body">
      <el-row :gutter="20">
        <el-col :span="8">
          <div class="label-wrap">
            <label>所属机构：</label>
            <span>测试</span>
          </div>
        </el-col>
        <el-col :span="8">
          <div class="label-wrap">
            <label>使用路线：</label>
            <span>测试</span>
          </div>
        </el-col>
        <el-col :span="8">
          <div class="label-wrap">
            <label>任务名称：</label>
            <span>测试</span>
          </div>
        </el-col>
        <el-col :span="8">
          <div class="label-wrap">
            <label>执行人：</label>
            <span>测试</span>
          </div>
        </el-col>
        <el-col :span="8">
          <div class="label-wrap">
            <label>抄送人：</label>
            <span>测试</span>
          </div>
        </el-col>
        <el-col :span="8">
          <div class="label-wrap">
            <label>状态：</label>
            <span>测试</span>
          </div>
        </el-col>
        <el-col :span="8">
          <div class="label-wrap">
            <label>频次类别：</label>
            <span>测试</span>
          </div>
        </el-col>
        <el-col :span="8">
          <div class="label-wrap">
            <label>频次：</label>
            <span>测试</span>
          </div>
        </el-col>
        <el-col :span="8">
          <div class="label-wrap">
            <label>生效时间：</label>
            <span>测试</span>
          </div>
        </el-col>
        <el-col :span="8">
          <div class="label-wrap">
            <label>预计耗时：</label>
            <span>测试</span>
          </div>
        </el-col>
        <el-col :span="24">
          <div class="label-wrap">
            <label>描述：</label>
            <span>测试</span>
          </div>
        </el-col>
      </el-row>
    </div>
</template>

<script>
    export default {
        name: "detailconfig"
    }
</script>

<style scoped>

</style>
