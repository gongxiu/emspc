<template>
    <div class="com-body">
      <div class="">
        <el-row :gutter="20">
          <el-col :span="8">
            <div class="label-wrap">
              <label>设备条码：</label>
              <span>测试</span>
            </div>
          </el-col>
          <el-col :span="8">
            <div class="label-wrap">
              <label>设备编码：</label>
              <span>测试</span>
            </div>
          </el-col>
          <el-col :span="8">
            <div class="label-wrap">
              <label>设备名称：</label>
              <span>测试</span>
            </div>
          </el-col>
          <el-col :span="8">
            <div class="label-wrap">
              <label>所属仓库：</label>
              <span>测试</span>
            </div>
          </el-col>
          <el-col :span="8">
            <div class="label-wrap">
              <label>备件类型：</label>
              <span>测试</span>
            </div>
          </el-col>
          <el-col :span="8">
            <div class="label-wrap">
              <label>生命类型：</label>
              <span>测试</span>
            </div>
          </el-col>
          <el-col :span="8">
            <div class="label-wrap">
              <label>剩余次数：</label>
              <span>测试</span>
            </div>
          </el-col>
          <el-col :span="8">
            <div class="label-wrap">
              <label>总生命：</label>
              <span>测试</span>
            </div>
          </el-col>
          <el-col :span="8">
            <div class="label-wrap">
              <label>截止日期：</label>
              <span>测试</span>
            </div>
          </el-col>
          <el-col :span="8">
            <div class="label-wrap">
              <label>是否重置：</label>
              <span>测试</span>
            </div>
          </el-col>
          <el-col :span="8">
            <div class="label-wrap">
              <label>重置次数：</label>
              <span>测试</span>
            </div>
          </el-col>
          <el-col :span="8">
            <div class="label-wrap">
              <label>供应商：</label>
              <span>测试</span>
            </div>
          </el-col>
          <el-col :span="8">
            <div class="label-wrap">
              <label>备件原值：</label>
              <span>测试</span>
            </div>
          </el-col>
          <el-col :span="8">
            <div class="label-wrap">
              <label>购置时间：</label>
              <span>测试</span>
            </div>
          </el-col>
          <el-col :span="8">
            <div class="label-wrap">
              <label>出厂时间：</label>
              <span>测试</span>
            </div>
          </el-col>
          <el-col :span="8">
            <div class="label-wrap">
              <label>生成时间：</label>
              <span>测试</span>
            </div>
          </el-col>
        </el-row>
      </div>
    </div>
</template>

<script>
    export default {
        name: "detail"
    }
</script>

<style scoped>

</style>
