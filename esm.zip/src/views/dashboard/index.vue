<template>
    <div class="login">
     我是模板页面
    </div>
  </template>
  <script>
   
  </script>
  
  <style rel="stylesheet/scss" lang="scss">
    
  </style>
  