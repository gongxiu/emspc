<template>
    <div class="com-body">
      <el-row :gutter="20">
        <el-col :span="8">
          <div class="label-wrap">
            <label>项目名称：</label>
            <span>测试</span>
          </div>
        </el-col>
        <el-col :span="8">
          <div class="label-wrap">
            <label>项目编码：</label>
            <span>测试</span>
          </div>
        </el-col>
        <el-col :span="8">
          <div class="label-wrap">
            <label>绑定设备：</label>
            <span>测试</span>
          </div>
        </el-col>
        <el-col :span="8">
          <div class="label-wrap">
            <label>保养人：</label>
            <span>测试</span>
          </div>
        </el-col>
        <el-col :span="8">
          <div class="label-wrap">
            <label>保养频次类别：</label>
            <span>测试</span>
          </div>
        </el-col>
        <el-col :span="8">
          <div class="label-wrap">
            <label>保养频次：</label>
            <span>测试</span>
          </div>
        </el-col>
        <el-col :span="8">
          <div class="label-wrap">
            <label>起始日期：</label>
            <span>测试</span>
          </div>
        </el-col>
        <el-col :span="8">
          <div class="label-wrap">
            <label>预计耗时：</label>
            <span>测试</span>
          </div>
        </el-col>
        <el-col :span="24">
          <div class="label-wrap">
            <label>项目要求：</label>
            <span>测试</span>
          </div>
        </el-col>
        <el-col :span="24">
          <div class="label-wrap">
            <label>注意事项：</label>
            <span>测试</span>
          </div>
        </el-col>
        <el-col :span="24">
          <div class="label-wrap">
            <label>描述：</label>
            <span>测试</span>
          </div>
        </el-col>
        <el-col :span="24">
          <div class="label-wrap">
            <label>保养结果：</label>
            <span>测试</span>
          </div>
        </el-col>
      </el-row>
    </div>
</template>

<script>
    export default {
        name: "detailexecu"
    }
</script>

<style scoped>

</style>
