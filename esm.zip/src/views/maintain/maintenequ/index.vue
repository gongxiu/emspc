<template>
    <div class="">
      设置保养设备
    </div>
</template>

<script>
    export default {
        name: "index"
    }
</script>

<style scoped>

</style>
